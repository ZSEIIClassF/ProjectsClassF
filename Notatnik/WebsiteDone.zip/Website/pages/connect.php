<?php

$host = 'mysql4.webio.pl';
$db_user = '22041_admin';
$db_password = 'Z0h7N9klZa1[P]';
$db_name = '22041_notatnik';

?>